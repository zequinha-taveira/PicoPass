# firmware/micropython/device.py
import machine
import utime
import sys
import uselect
from keyboard import PicoPassHID

class PicoPassDevice:
    def __init__(self):
        # Hardware Setup
        self.led = machine.Pin(25, machine.Pin.OUT) # Onboard LED
        self.status_led = machine.Pin(16, machine.Pin.OUT) # External Status LED
        self.btn_action = machine.Pin(15, machine.Pin.IN, machine.Pin.PULL_UP)
        
        # Components
        self.hid = PicoPassHID()
        
        # State
        self.locked = True
        self.pending_password = None
        
        # Serial Polling
        self.poll = uselect.poll()
        self.poll.register(sys.stdin, uselect.POLLIN)

    def blink(self, times=1, delay=0.1):
        for _ in range(times):
            self.led.value(1)
            utime.sleep(delay)
            self.led.value(0)
            utime.sleep(delay)

    def handle_serial(self):
        if self.poll.poll(0):
            line = sys.stdin.readline().strip()
            if not line: return
            
            if line == "PING":
                print("PONG")
            elif line.startswith("TYPE:"):
                # Protocol: TYPE:password_content
                self.pending_password = line[5:]
                self.blink(2) # Visual feedback that data was received
                print("READY_TO_TYPE")
            elif line == "LOCK":
                self.locked = True
                print("LOCKED")

    def run(self):
        print("PicoPass Firmware v0.5 Starting...")
        self.blink(3)
        
        while True:
            self.handle_serial()
            
            # Check button press for typing
            if not self.btn_action.value(): # Button pressed (active low)
                if self.pending_password:
                    self.blink(1, 0.5) # Wait signal
                    self.hid.type_text(self.pending_password)
                    self.pending_password = None
                    print("TYPING_DONE")
                else:
                    # Blink error if no password pending
                    self.blink(5, 0.05)
                
                # Debounce
                while not self.btn_action.value():
                    utime.sleep(0.01)

            utime.sleep(0.01)

if __name__ == "__main__":
    device = PicoPassDevice()
    device.run()
